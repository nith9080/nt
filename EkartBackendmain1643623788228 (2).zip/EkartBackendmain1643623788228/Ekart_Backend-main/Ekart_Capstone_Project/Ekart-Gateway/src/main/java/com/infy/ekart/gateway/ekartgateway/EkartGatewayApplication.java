package com.infy.ekart.gateway.ekartgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EkartGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(EkartGatewayApplication.class, args);
	}

}
