package com.infy.ekart.gateway.ekartgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkartGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
